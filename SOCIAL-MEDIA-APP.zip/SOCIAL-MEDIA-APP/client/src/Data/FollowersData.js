import img1 from "../img/img1.png";
import img2 from "../img/img2.png";
import img3 from "../img/img3.png";
import img4 from "../img/img4.jpg";

export const Followers = [
    {name: "Andrew", username: "Andrew", img:img1},
    {name: "Hulk", username: "Hulk", img:img2},
    {name: "Thor", username: "Thor", img:img3},
    {name: "Natasah", username: "Natasha", img:img4},
];